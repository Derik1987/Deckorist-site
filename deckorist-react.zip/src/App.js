
import React from 'react';

function App() {
  return (
    <div style={{ textAlign: 'center', marginTop: '4rem' }}>
      <h1>Welcome to Deckorist!</h1>
      <p>Your professional deck builders in DMV area.</p>
    </div>
  );
}

export default App;
